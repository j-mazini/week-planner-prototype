# Route Balance — exportação React

Exportação visual de **23 telas e estados** (16 desktop e 7 mobile), mais **16 referências** de componentes, capa e handoff, do [Route Balance no Figma](https://www.figma.com/design/4emNFZL0KFWcXlYce6B7L5/Route-Balance?node-id=87-3).

## Executar

Requer Node.js 22.12+ ou 24 e npm.

```bash
npm ci
npm run dev
```

Abra o endereço exibido no terminal. O índice permite buscar por nome ou ID do Figma e navegar por todas as telas. Use as setas para avançar e voltar, “Ajustado” para alternar a escala e “Abrir tela” para visualizar apenas o design.

```bash
npm run build
npm run preview
```

A pasta `dist/` contém uma versão já compilada, com fontes e assets locais. Sirva essa pasta por HTTP. Abrir o HTML diretamente como `file://` não permite carregar os dados JSON.

## Estrutura

- `src/screens/`: componente React individual para cada item.
- `src/components/FigmaScreen.tsx`: renderizador compartilhado das camadas.
- `public/screens/`: conteúdo e estilos de cada tela.
- `public/assets/`: vetores SVG originais e imagens dos formulários.
- `src/manifest.json`: nomes, IDs, dimensões e grupos do índice.
- `SCREENS.md`: inventário completo dos 39 itens.
- `export-report.json`: composição de sobreposições e registro de vetores vazios.
- `VALIDATION.json`: resultado da verificação de carregamento e navegação.

O projeto usa React, TypeScript, Vite e CSS sem Tailwind. IBM Plex Mono, Space Grotesk, Inter, Roboto e Geist são fornecidas localmente pelos pacotes Fontsource. Não há dependência de URLs temporárias do Figma.

## Reutilizar uma tela

```tsx
import { Screen198_6865 } from './screens';

export default function App() {
  return <Screen198_6865 />;
}
```

Mantenha `public/screens/` e `public/assets/` disponíveis na raiz pública e preserve os imports de fontes em `src/main.tsx`. Para usar outro bundler, adapte `import.meta.env.BASE_URL` no renderizador à URL pública do projeto.

Cada camada preserva o ID original em `data-node-id`. Para editar um texto ou estilo, localize esse ID em `public/screens/<id>.json`. O campo `s` aponta para a entrada em `styles`; `text` contém o texto e `c` contém as camadas filhas. Elementos que já estavam convertidos em curvas no Figma permanecem vetores SVG.

## Telas incluídas

Desktop: visão geral, cards expandidos, rota flexível, detalhes da remessa, todas as paradas, importação inicial e processada, confirmação de importação, entregas especiais e cinco estados do seletor de códigos postais.

Mobile: rota ativa, entregas especiais, todas as paradas, detalhes da remessa, relatório de acidente, relatório de problema e finalização da rota.

Referências: card recolhido, card expandido, mensagem de sucesso, capa e os 12 quadros da página Handoff, incluindo tokens, tipografia, cores, layout, especificações, funcionalidades e catálogo de componentes.

Os modais que estavam soltos no canvas foram reunidos aos fundos correspondentes. A mensagem de importação foi incluída na tela de confirmação e também está disponível isoladamente como referência. Os IDs envolvidos nessas composições constam em `export-report.json`. Textos explicativos soltos e fundos decorativos do canvas não são telas independentes.

## Escopo

Esta é uma **exportação visual editável em React**. Textos e containers são elementos DOM; as telas não são imagens de página inteira. Busca, navegação e controles do visualizador funcionam. Os botões do produto desenhados nas telas não executam regras de negócio: processamento de planilhas, envio a motoristas, cadastro, formulários, uploads e integrações exigem implementação adicional.

As telas preservam as dimensões e posições do Figma. O ajuste à janela é proporcional; as versões mobile são telas próprias. A exportação não inventa breakpoints ou reorganização responsiva. Camadas invisíveis ou totalmente ocultas por máscaras não são desenhadas. Pequenas diferenças de antialiasing e efeitos entre Figma e navegador podem ocorrer.

## Verificação

Compilação com TypeScript e Vite; abertura dos 39 itens em Chromium para verificar assets locais, erros JavaScript e navegação. Revisão visual das telas principais desktop, mobile e sobreposições.
