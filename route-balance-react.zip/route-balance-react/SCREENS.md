# Inventário de telas

| Tela | Grupo | ID Figma | Dimensões | Componente |
| --- | --- | --- | --- | --- |
| Route Balance — visão geral | Desktop | 198:6865 | 1281 × 1006 | `Screen198_6865` |
| Rotas — cards expandidos | Desktop | 200:9214 | 1281 × 1443 | `Screen200_9214` |
| Adicionar rota flexível | Desktop | 132:8083 | 1282 × 1213 | `Screen132_8083` |
| Detalhes da remessa | Desktop | 132:8635 | 1282 × 1223 | `Screen132_8635` |
| Todas as paradas | Desktop | 132:9631 | 1282 × 1213 | `Screen132_9631` |
| Importação — enviar arquivo | Desktop | 199:8100 | 1280 × 816 | `Screen199_8100` |
| Importação — dados processados | Desktop | 199:8224 | 1280 × 1406 | `Screen199_8224` |
| Adicionar código postal | Desktop | 211:15663 | 1284 × 1213 | `Screen211_15663` |
| Códigos postais — lista aberta | Desktop | 211:16495 | 1284 × 1213 | `Screen211_16495` |
| Códigos postais — seleção | Desktop | 211:17023 | 1284 × 1213 | `Screen211_17023` |
| Códigos postais — múltiplos selecionados | Desktop | 212:6812 | 1284 × 1213 | `Screen212_6812` |
| Códigos postais — seleção extensa | Desktop | 211:17589 | 1284 × 1213 | `Screen211_17589` |
| Rotas — entregas especiais | Desktop | 257:10450 | 1281 × 1085 | `Screen257_10450` |
| Entregas especiais — detalhes | Desktop | 320:14396 | 1282 × 1072 | `Screen320_14396` |
| Importação — confirmação de sucesso | Desktop | 301:6379 | 1281 × 1445 | `Screen301_6379` |
| Rotas — após importação | Desktop | 301:7061 | 1281 × 1445 | `Screen301_7061` |
| Mobile — rota ativa | Mobile | 322:14616 | 390 × 844 | `Screen322_14616` |
| Mobile — entregas especiais | Mobile | 322:14709 | 390 × 844 | `Screen322_14709` |
| Mobile — todas as paradas | Mobile | 322:14843 | 390 × 844 | `Screen322_14843` |
| Mobile — detalhes da remessa | Mobile | 322:14978 | 390 × 844 | `Screen322_14978` |
| Mobile — relatar acidente | Mobile | 397:8215 | 390 × 844 | `Screen397_8215` |
| Mobile — relatar problema | Mobile | 397:8351 | 390 × 844 | `Screen397_8351` |
| Mobile — finalizar rota | Mobile | 397:8488 | 390 × 844 | `Screen397_8488` |
| Componente — card recolhido | Referências | 217:45665 | 253 × 281.333 | `Screen217_45665` |
| Componente — card expandido | Referências | 217:45384 | 253 × 490.8 | `Screen217_45384` |
| Componente — mensagem de sucesso | Referências | 301:7053 | 443 × 47 | `Screen301_7053` |
| Token Documentation — Color | Referências | 141:6722 | 1280 × 3177 | `Screen141_6722` |
| Token Documentation — Typography | Referências | 141:6907 | 1280 × 1145 | `Screen141_6907` |
| Token Documentation — Paint Styles | Referências | 141:6974 | 1280 × 745 | `Screen141_6974` |
| Handoff — Component Layout Specs | Referências | 320:9690 | 1440 × 2192 | `Screen320_9690` |
| Handoff — Style Guide | Referências | 320:10067 | 1440 × 1436 | `Screen320_10067` |
| Handoff — Paleta de Cores | Referências | 320:10127 | 1440 × 2690 | `Screen320_10127` |
| Handoff — Tipografia | Referências | 320:10339 | 1440 × 1604 | `Screen320_10339` |
| Handoff — Espaçamento & Layout | Referências | 320:10465 | 1440 × 3517 | `Screen320_10465` |
| Handoff — Especificações de Componentes | Referências | 320:10682 | 1440 × 3620 | `Screen320_10682` |
| Handoff — Funcionalidades | Referências | 320:10900 | 1440 × 2849 | `Screen320_10900` |
| Componentes | Referências | 320:11087 | 1208 × 7188 | `Screen320_11087` |
| Handoff | Referências | 320:11093 | 1280 × 3213.133 | `Screen320_11093` |
| Capa | Referências | 141:6400 | 1280 × 720 | `Screen141_6400` |
