import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar rota flexível · Figma 132:8083 */
export default function Screen132_8083() {
  return <FigmaScreen screenId="132-8083" />;
}
