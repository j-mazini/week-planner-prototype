import { FigmaScreen } from "../components/FigmaScreen";

/** Detalhes da remessa · Figma 132:8635 */
export default function Screen132_8635() {
  return <FigmaScreen screenId="132-8635" />;
}
