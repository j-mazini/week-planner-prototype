import { FigmaScreen } from "../components/FigmaScreen";

/** Todas as paradas · Figma 132:9631 */
export default function Screen132_9631() {
  return <FigmaScreen screenId="132-9631" />;
}
