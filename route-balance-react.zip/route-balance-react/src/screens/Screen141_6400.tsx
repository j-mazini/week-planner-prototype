import { FigmaScreen } from "../components/FigmaScreen";

/** Capa · Figma 141:6400 */
export default function Screen141_6400() {
  return <FigmaScreen screenId="141-6400" />;
}
