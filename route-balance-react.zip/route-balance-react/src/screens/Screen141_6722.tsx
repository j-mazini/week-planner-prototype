import { FigmaScreen } from "../components/FigmaScreen";

/** Token Documentation — Color · Figma 141:6722 */
export default function Screen141_6722() {
  return <FigmaScreen screenId="141-6722" />;
}
