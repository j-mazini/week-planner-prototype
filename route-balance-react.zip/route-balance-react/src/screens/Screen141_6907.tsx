import { FigmaScreen } from "../components/FigmaScreen";

/** Token Documentation — Typography · Figma 141:6907 */
export default function Screen141_6907() {
  return <FigmaScreen screenId="141-6907" />;
}
