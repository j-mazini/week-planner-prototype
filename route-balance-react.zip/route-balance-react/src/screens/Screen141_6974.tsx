import { FigmaScreen } from "../components/FigmaScreen";

/** Token Documentation — Paint Styles · Figma 141:6974 */
export default function Screen141_6974() {
  return <FigmaScreen screenId="141-6974" />;
}
