import { FigmaScreen } from "../components/FigmaScreen";

/** Route Balance — visão geral · Figma 198:6865 */
export default function Screen198_6865() {
  return <FigmaScreen screenId="198-6865" />;
}
