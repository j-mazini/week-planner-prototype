import { FigmaScreen } from "../components/FigmaScreen";

/** Importação — enviar arquivo · Figma 199:8100 */
export default function Screen199_8100() {
  return <FigmaScreen screenId="199-8100" />;
}
