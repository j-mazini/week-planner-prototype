import { FigmaScreen } from "../components/FigmaScreen";

/** Importação — dados processados · Figma 199:8224 */
export default function Screen199_8224() {
  return <FigmaScreen screenId="199-8224" />;
}
