import { FigmaScreen } from "../components/FigmaScreen";

/** Rotas — cards expandidos · Figma 200:9214 */
export default function Screen200_9214() {
  return <FigmaScreen screenId="200-9214" />;
}
