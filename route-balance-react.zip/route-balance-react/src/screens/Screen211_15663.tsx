import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar código postal · Figma 211:15663 */
export default function Screen211_15663() {
  return <FigmaScreen screenId="211-15663" />;
}
