import { FigmaScreen } from "../components/FigmaScreen";

/** Códigos postais — lista aberta · Figma 211:16495 */
export default function Screen211_16495() {
  return <FigmaScreen screenId="211-16495" />;
}
