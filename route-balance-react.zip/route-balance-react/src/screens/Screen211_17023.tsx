import { FigmaScreen } from "../components/FigmaScreen";

/** Códigos postais — seleção · Figma 211:17023 */
export default function Screen211_17023() {
  return <FigmaScreen screenId="211-17023" />;
}
