import { FigmaScreen } from "../components/FigmaScreen";

/** Códigos postais — seleção extensa · Figma 211:17589 */
export default function Screen211_17589() {
  return <FigmaScreen screenId="211-17589" />;
}
