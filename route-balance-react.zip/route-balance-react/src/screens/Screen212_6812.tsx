import { FigmaScreen } from "../components/FigmaScreen";

/** Códigos postais — múltiplos selecionados · Figma 212:6812 */
export default function Screen212_6812() {
  return <FigmaScreen screenId="212-6812" />;
}
