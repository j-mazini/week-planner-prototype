import { FigmaScreen } from "../components/FigmaScreen";

/** Componente — card expandido · Figma 217:45384 */
export default function Screen217_45384() {
  return <FigmaScreen screenId="217-45384" />;
}
