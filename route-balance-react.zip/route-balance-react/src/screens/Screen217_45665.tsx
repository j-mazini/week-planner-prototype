import { FigmaScreen } from "../components/FigmaScreen";

/** Componente — card recolhido · Figma 217:45665 */
export default function Screen217_45665() {
  return <FigmaScreen screenId="217-45665" />;
}
