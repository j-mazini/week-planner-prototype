import { FigmaScreen } from "../components/FigmaScreen";

/** Rotas — entregas especiais · Figma 257:10450 */
export default function Screen257_10450() {
  return <FigmaScreen screenId="257-10450" />;
}
