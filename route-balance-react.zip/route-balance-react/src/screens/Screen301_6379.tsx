import { FigmaScreen } from "../components/FigmaScreen";

/** Importação — confirmação de sucesso · Figma 301:6379 */
export default function Screen301_6379() {
  return <FigmaScreen screenId="301-6379" />;
}
