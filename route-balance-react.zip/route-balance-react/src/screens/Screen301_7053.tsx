import { FigmaScreen } from "../components/FigmaScreen";

/** Componente — mensagem de sucesso · Figma 301:7053 */
export default function Screen301_7053() {
  return <FigmaScreen screenId="301-7053" />;
}
