import { FigmaScreen } from "../components/FigmaScreen";

/** Rotas — após importação · Figma 301:7061 */
export default function Screen301_7061() {
  return <FigmaScreen screenId="301-7061" />;
}
