import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Style Guide · Figma 320:10067 */
export default function Screen320_10067() {
  return <FigmaScreen screenId="320-10067" />;
}
