import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Paleta de Cores · Figma 320:10127 */
export default function Screen320_10127() {
  return <FigmaScreen screenId="320-10127" />;
}
