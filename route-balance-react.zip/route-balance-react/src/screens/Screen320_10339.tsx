import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Tipografia · Figma 320:10339 */
export default function Screen320_10339() {
  return <FigmaScreen screenId="320-10339" />;
}
