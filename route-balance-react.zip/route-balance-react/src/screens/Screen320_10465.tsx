import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Espaçamento & Layout · Figma 320:10465 */
export default function Screen320_10465() {
  return <FigmaScreen screenId="320-10465" />;
}
