import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Especificações de Componentes · Figma 320:10682 */
export default function Screen320_10682() {
  return <FigmaScreen screenId="320-10682" />;
}
