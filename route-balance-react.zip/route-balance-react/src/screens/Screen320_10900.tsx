import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Funcionalidades · Figma 320:10900 */
export default function Screen320_10900() {
  return <FigmaScreen screenId="320-10900" />;
}
