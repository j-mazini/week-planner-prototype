import { FigmaScreen } from "../components/FigmaScreen";

/** Componentes · Figma 320:11087 */
export default function Screen320_11087() {
  return <FigmaScreen screenId="320-11087" />;
}
