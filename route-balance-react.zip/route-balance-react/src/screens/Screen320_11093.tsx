import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff · Figma 320:11093 */
export default function Screen320_11093() {
  return <FigmaScreen screenId="320-11093" />;
}
