import { FigmaScreen } from "../components/FigmaScreen";

/** Entregas especiais — detalhes · Figma 320:14396 */
export default function Screen320_14396() {
  return <FigmaScreen screenId="320-14396" />;
}
