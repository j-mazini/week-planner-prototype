import { FigmaScreen } from "../components/FigmaScreen";

/** Handoff — Component Layout Specs · Figma 320:9690 */
export default function Screen320_9690() {
  return <FigmaScreen screenId="320-9690" />;
}
