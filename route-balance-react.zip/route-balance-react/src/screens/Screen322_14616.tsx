import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — rota ativa · Figma 322:14616 */
export default function Screen322_14616() {
  return <FigmaScreen screenId="322-14616" />;
}
