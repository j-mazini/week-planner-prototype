import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — entregas especiais · Figma 322:14709 */
export default function Screen322_14709() {
  return <FigmaScreen screenId="322-14709" />;
}
