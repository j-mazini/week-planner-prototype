import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — todas as paradas · Figma 322:14843 */
export default function Screen322_14843() {
  return <FigmaScreen screenId="322-14843" />;
}
