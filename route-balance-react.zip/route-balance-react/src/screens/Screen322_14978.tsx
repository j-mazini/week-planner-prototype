import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — detalhes da remessa · Figma 322:14978 */
export default function Screen322_14978() {
  return <FigmaScreen screenId="322-14978" />;
}
