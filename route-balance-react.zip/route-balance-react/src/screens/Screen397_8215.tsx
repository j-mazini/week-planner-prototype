import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — relatar acidente · Figma 397:8215 */
export default function Screen397_8215() {
  return <FigmaScreen screenId="397-8215" />;
}
