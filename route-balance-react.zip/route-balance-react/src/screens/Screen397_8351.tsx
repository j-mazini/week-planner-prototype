import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — relatar problema · Figma 397:8351 */
export default function Screen397_8351() {
  return <FigmaScreen screenId="397-8351" />;
}
