import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — finalizar rota · Figma 397:8488 */
export default function Screen397_8488() {
  return <FigmaScreen screenId="397-8488" />;
}
