# Week Planner — exportação React

Exportação visual de **22 telas e estados**, mais **3 quadros de referência**, do arquivo [Week Planner no Figma](https://www.figma.com/design/Qx1Tf0v03GgwzvaGt2Y6Vw/Week-Planner?node-id=2252-19446).

## Executar

Requer Node.js 22.12+ ou 24 e npm.

```bash
npm ci
npm run dev
```

Abra o endereço exibido no terminal. Use o índice lateral para abrir qualquer tela. A busca aceita nome ou ID do Figma; as setas avançam e voltam. “Ajustado” alterna entre ajuste à janela e tamanho original; “Abrir tela” remove o visualizador.

```bash
npm run build
npm run preview
```

A pasta `dist/` inclui a versão compilada, com assets e fontes locais. Ela deve ser servida por HTTP; abrir `index.html` diretamente como `file://` não carrega os dados JSON.

## Conteúdo

- React, TypeScript e Vite, com CSS sem Tailwind.
- Um componente exportável para cada tela em `src/screens/`.
- Renderizador compartilhado em `src/components/FigmaScreen.tsx`.
- Conteúdo, estilos e camadas separados por tela em `public/screens/`.
- SVGs originais em `public/assets/`, sem dependência de URLs temporárias do Figma.
- Fontes IBM Plex Mono e Space Grotesk fornecidas pelos pacotes Fontsource.
- IDs originais preservados em `data-node-id` para localizar cada camada no Figma.
- Inventário completo em `SCREENS.md` e `src/manifest.json`.

## Reutilizar uma tela

```tsx
import { Screen2252_19446 } from './screens';

export default function App() {
  return <Screen2252_19446 />;
}
```

Mantenha `public/screens/` e `public/assets/` disponíveis na raiz pública da aplicação e preserve os imports de fontes de `src/main.tsx`. O renderizador usa `import.meta.env.BASE_URL`, fornecido pelo Vite; em outro bundler, adapte essa constante à URL pública do projeto.

Para editar um texto ou uma dimensão, localize o ID em `public/screens/<id>.json`. Cada nó tem um índice `s` para a entrada correspondente em `styles`. Os campos `text` e `c` representam o texto e os filhos. Os SVGs preservam vetores que já estavam convertidos em curvas no arquivo original.

## Escopo da exportação

Esta entrega reproduz os **estados visuais** existentes no Figma. Os textos são elementos DOM, e os containers são camadas React; as telas não são imagens de página inteira. A navegação, busca e controles do visualizador funcionam. Os controles do produto representados dentro das telas não executam operações de negócio: salvar dados, cadastrar rotas, gerar PDFs, autenticar usuários e integrar APIs exigem implementação adicional.

Os layouts preservam as dimensões e posições do design. O visualizador pode redimensionar a tela proporcionalmente. As versões mobile e ultrawide são telas próprias; a exportação não inventa breakpoints ou reorganização responsiva que não estejam no arquivo.

Foram incluídos todos os frames de telas e o grupo de detalhes mobile da página Layout, a capa e os dois quadros de componentes. Textos explicativos soltos, fundos decorativos do canvas, a imagem de referência solta e a camada isolada de escurecimento não constituem telas independentes. Camadas invisíveis ou totalmente ocultas por máscaras não são desenhadas. Alguns vetores vazios não geram arquivo SVG; seus IDs estão registrados em `export-report.json`.

## Verificação

O projeto foi compilado com TypeScript e Vite. Os 25 itens foram abertos em Chromium para verificar carregamento, ausência de erros JavaScript, assets locais e navegação. Foram conferidas visualmente as telas desktop, mobile e estados com sobreposições. Pequenas diferenças de antialiasing e efeitos entre Figma e navegador podem ocorrer.
