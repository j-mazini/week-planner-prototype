# Inventário de telas

| Tela | Grupo | ID Figma | Dimensões | Componente |
| --- | --- | --- | --- | --- |
| Planejador semanal | Desktop | 2192:18133 | 1440 × 1016 | `Screen2192_18133` |
| Mobile — minha semana | Mobile | 2087:9145 | 390 × 830 | `Screen2087_9145` |
| Mobile — detalhes do dia | Mobile | 2087:9226 | 390 × 830 | `Screen2087_9226` |
| Mobile — painel de detalhes | Mobile | 2117:9168 | 369.391 × 520.016 | `Screen2117_9168` |
| Ultrawide — planejador | Ultrawide | 2163:20071 | 2560 × 1212 | `Screen2163_20071` |
| Ultrawide — painel lateral | Ultrawide | 2179:55954 | 2560 × 1352 | `Screen2179_55954` |
| Seletor de semana | Desktop | 2252:19446 | 1440 × 1027 | `Screen2252_19446` |
| Registrar folga | Desktop | 2193:25586 | 1440 × 1278 | `Screen2193_25586` |
| Associar gestão e suporte | Desktop | 2193:32515 | 1440 × 1278 | `Screen2193_32515` |
| Adicionar serviço ADHOC | Desktop | 2193:33874 | 1440 × 1278 | `Screen2193_33874` |
| Adicionar líder de equipe | Desktop | 2193:36456 | 1440 × 1278 | `Screen2193_36456` |
| Adicionar rota flexível | Desktop | 2193:37747 | 1440 × 1278 | `Screen2193_37747` |
| Adicionar atribuição | Desktop | 2193:26875 | 1440 × 1278 | `Screen2193_26875` |
| Exportar dia | Desktop | 2193:28164 | 1440 × 1278 | `Screen2193_28164` |
| Exportar semana | Desktop | 2193:29453 | 1440 × 1278 | `Screen2193_29453` |
| Semana gerada — confirmação | Desktop | 2193:30742 | 1440 × 1278 | `Screen2193_30742` |
| Adicionar anotação | Desktop | 2194:39755 | 1440 × 1278 | `Screen2194_39755` |
| Editar atribuição | Desktop | 2224:32076 | 1440 × 1278 | `Screen2224_32076` |
| Planejamento e notas | Desktop | 2249:22899 | 1440 × 1026 | `Screen2249_22899` |
| Notas — edição e salvamento | Desktop | 2258:22098 | 1440 × 1026 | `Screen2258_22098` |
| Tooltip de atribuição | Desktop | 2258:28057 | 1440 × 1026 | `Screen2258_28057` |
| Conteúdo completo do painel | Desktop | 2264:23511 | 1305 × 1310 | `Screen2264_23511` |
| Capa | Referências | 141:6400 | 1280 × 720 | `Screen141_6400` |
| Catálogo de componentes | Referências | 2130:19618 | 2680 × 7351 | `Screen2130_19618` |
| Variantes da barra lateral | Referências | 2179:58772 | 341 × 1046 | `Screen2179_58772` |
