import {useEffect,useState} from 'react';
import manifest from './manifest.json';
import {FigmaScreen} from './components/FigmaScreen';
const currentId=()=>location.hash.slice(1)||'2192-18133';
export default function App(){
 const [id,setId]=useState(currentId);const [query,setQuery]=useState('');const [fit,setFit]=useState(true);const [menu,setMenu]=useState(true);const [vw,setVw]=useState(innerWidth);
 const clean=new URLSearchParams(location.search).has('screen');
 useEffect(()=>{const hash=()=>setId(currentId());const resize=()=>setVw(innerWidth);addEventListener('hashchange',hash);addEventListener('resize',resize);return()=>{removeEventListener('hashchange',hash);removeEventListener('resize',resize);};},[]);
 const screen=manifest.find(s=>s.slug===id)??manifest[0];const index=manifest.indexOf(screen);const available=vw-(menu?288:0)-48;const scale=clean||!fit?1:Math.min(1,Math.max(200,available)/screen.width);
 const go=(offset:number)=>{location.hash=manifest[(index+offset+manifest.length)%manifest.length].slug};
 if(clean)return <FigmaScreen screenId={screen.slug}/>;
 return <div className="app-shell">
  <header className="viewer-header"><button onClick={()=>setMenu(!menu)} aria-label={menu?'Ocultar índice':'Mostrar índice'}>☰</button><div><strong>WEEK PLANNER</strong><small>EXPORTAÇÃO REACT · 25 ITENS</small></div><span className="header-count">{String(index+1).padStart(2,'0')} / 25</span><button onClick={()=>go(-1)} aria-label="Tela anterior">←</button><button onClick={()=>go(1)} aria-label="Próxima tela">→</button></header>
  {menu&&<aside className="screen-index"><input aria-label="Buscar telas" placeholder="Buscar tela ou ID…" value={query} onChange={e=>setQuery(e.target.value)}/>{['Desktop','Ultrawide','Mobile','Referências'].map(group=><section key={group}><h2>{group}</h2>{manifest.filter(s=>s.group===group&&`${s.name} ${s.id}`.toLowerCase().includes(query.toLowerCase())).map(s=><a href={`#${s.slug}`} className={s.slug===screen.slug?'active':''} key={s.slug} aria-current={s.slug===screen.slug?'page':undefined}><span>{s.name}</span><small>{s.width} × {s.height} · {s.id}</small></a>)}</section>)}</aside>}
  <main className="viewer-main" style={{marginLeft:menu?288:0}}><div className="screen-toolbar"><div><h1>{screen.name}</h1><p>{screen.figmaName} · {screen.width} × {screen.height}</p></div><div className="toolbar-actions"><button onClick={()=>setFit(!fit)} aria-pressed={fit}>{fit?'Ajustado':'100%'} · {Math.round(scale*100)}%</button><a href={`?screen#${screen.slug}`} target="_blank" rel="noreferrer">Abrir tela</a><a href={`https://www.figma.com/design/Qx1Tf0v03GgwzvaGt2Y6Vw/Week-Planner?node-id=${screen.slug}`} target="_blank" rel="noreferrer">Figma ↗</a></div></div><div className="canvas-scroller"><div className="canvas-size" style={{width:screen.width*scale,height:screen.height*scale}}><div style={{transform:`scale(${scale})`,transformOrigin:'top left',width:screen.width,height:screen.height}}><FigmaScreen screenId={screen.slug}/></div></div></div></main>
 </div>;
}
