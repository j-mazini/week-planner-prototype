import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — minha semana · Figma 2087:9145 */
export default function Screen2087_9145() {
  return <FigmaScreen screenId="2087-9145" />;
}
