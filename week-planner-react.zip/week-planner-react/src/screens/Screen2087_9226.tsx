import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — detalhes do dia · Figma 2087:9226 */
export default function Screen2087_9226() {
  return <FigmaScreen screenId="2087-9226" />;
}
