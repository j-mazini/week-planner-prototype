import { FigmaScreen } from "../components/FigmaScreen";

/** Mobile — painel de detalhes · Figma 2117:9168 */
export default function Screen2117_9168() {
  return <FigmaScreen screenId="2117-9168" />;
}
