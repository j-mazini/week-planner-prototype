import { FigmaScreen } from "../components/FigmaScreen";

/** Catálogo de componentes · Figma 2130:19618 */
export default function Screen2130_19618() {
  return <FigmaScreen screenId="2130-19618" />;
}
