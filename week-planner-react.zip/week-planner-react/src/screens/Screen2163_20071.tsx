import { FigmaScreen } from "../components/FigmaScreen";

/** Ultrawide — planejador · Figma 2163:20071 */
export default function Screen2163_20071() {
  return <FigmaScreen screenId="2163-20071" />;
}
