import { FigmaScreen } from "../components/FigmaScreen";

/** Ultrawide — painel lateral · Figma 2179:55954 */
export default function Screen2179_55954() {
  return <FigmaScreen screenId="2179-55954" />;
}
