import { FigmaScreen } from "../components/FigmaScreen";

/** Variantes da barra lateral · Figma 2179:58772 */
export default function Screen2179_58772() {
  return <FigmaScreen screenId="2179-58772" />;
}
