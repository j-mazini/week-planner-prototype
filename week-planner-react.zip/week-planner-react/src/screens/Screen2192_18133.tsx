import { FigmaScreen } from "../components/FigmaScreen";

/** Planejador semanal · Figma 2192:18133 */
export default function Screen2192_18133() {
  return <FigmaScreen screenId="2192-18133" />;
}
