import { FigmaScreen } from "../components/FigmaScreen";

/** Registrar folga · Figma 2193:25586 */
export default function Screen2193_25586() {
  return <FigmaScreen screenId="2193-25586" />;
}
