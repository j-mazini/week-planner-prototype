import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar atribuição · Figma 2193:26875 */
export default function Screen2193_26875() {
  return <FigmaScreen screenId="2193-26875" />;
}
