import { FigmaScreen } from "../components/FigmaScreen";

/** Exportar dia · Figma 2193:28164 */
export default function Screen2193_28164() {
  return <FigmaScreen screenId="2193-28164" />;
}
