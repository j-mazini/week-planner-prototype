import { FigmaScreen } from "../components/FigmaScreen";

/** Exportar semana · Figma 2193:29453 */
export default function Screen2193_29453() {
  return <FigmaScreen screenId="2193-29453" />;
}
