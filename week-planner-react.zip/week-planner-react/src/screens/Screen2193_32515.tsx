import { FigmaScreen } from "../components/FigmaScreen";

/** Associar gestão e suporte · Figma 2193:32515 */
export default function Screen2193_32515() {
  return <FigmaScreen screenId="2193-32515" />;
}
