import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar serviço ADHOC · Figma 2193:33874 */
export default function Screen2193_33874() {
  return <FigmaScreen screenId="2193-33874" />;
}
