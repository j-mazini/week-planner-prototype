import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar líder de equipe · Figma 2193:36456 */
export default function Screen2193_36456() {
  return <FigmaScreen screenId="2193-36456" />;
}
