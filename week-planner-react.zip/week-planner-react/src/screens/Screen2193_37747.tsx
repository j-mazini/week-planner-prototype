import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar rota flexível · Figma 2193:37747 */
export default function Screen2193_37747() {
  return <FigmaScreen screenId="2193-37747" />;
}
