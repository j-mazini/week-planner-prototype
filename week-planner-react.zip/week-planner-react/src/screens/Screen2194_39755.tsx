import { FigmaScreen } from "../components/FigmaScreen";

/** Adicionar anotação · Figma 2194:39755 */
export default function Screen2194_39755() {
  return <FigmaScreen screenId="2194-39755" />;
}
