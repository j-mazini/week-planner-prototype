import { FigmaScreen } from "../components/FigmaScreen";

/** Editar atribuição · Figma 2224:32076 */
export default function Screen2224_32076() {
  return <FigmaScreen screenId="2224-32076" />;
}
