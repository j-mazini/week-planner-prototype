import { FigmaScreen } from "../components/FigmaScreen";

/** Planejamento e notas · Figma 2249:22899 */
export default function Screen2249_22899() {
  return <FigmaScreen screenId="2249-22899" />;
}
