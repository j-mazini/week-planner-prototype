import { FigmaScreen } from "../components/FigmaScreen";

/** Seletor de semana · Figma 2252:19446 */
export default function Screen2252_19446() {
  return <FigmaScreen screenId="2252-19446" />;
}
