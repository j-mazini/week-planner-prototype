import { FigmaScreen } from "../components/FigmaScreen";

/** Notas — edição e salvamento · Figma 2258:22098 */
export default function Screen2258_22098() {
  return <FigmaScreen screenId="2258-22098" />;
}
