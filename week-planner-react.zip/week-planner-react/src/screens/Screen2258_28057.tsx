import { FigmaScreen } from "../components/FigmaScreen";

/** Tooltip de atribuição · Figma 2258:28057 */
export default function Screen2258_28057() {
  return <FigmaScreen screenId="2258-28057" />;
}
