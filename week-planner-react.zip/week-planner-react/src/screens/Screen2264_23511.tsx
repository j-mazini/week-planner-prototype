import { FigmaScreen } from "../components/FigmaScreen";

/** Conteúdo completo do painel · Figma 2264:23511 */
export default function Screen2264_23511() {
  return <FigmaScreen screenId="2264-23511" />;
}
